#include "types.h"
#include "user.h"
#include "stat.h"
#include "x86.h"
#include "fcntl.h"
#define PGSIZE (4096)

int thread_create(void (*start_routine)(void*), void *arg)
{
	void *stack ;
	stack = malloc(PGSIZE);
	//if((uint)stack % PGSIZE)
	   //stack = stack + (PGSIZE - (uint)stack % PGSIZE);
	//printf(1,"Before clone");
	int a =  clone(start_routine, arg, stack);
	//printf(1,"%d", a);
	return a;
}


int thread_join()
{
   void *stack;
   
    int a = join(&stack);


    if(a==-1)
       return -1;
    free(stack);
    return a;

	
}

void lock_init(lock_t *s)
{
   s->flag = 0;
}

void lock_acquire(lock_t *s)
{
    while(xchg(&s->flag, 1) != 0);
}

void lock_release(lock_t *s)
{
   xchg(&s->flag,0);
}


//void cond_init(cond_t 

void cond_init(cond_t *p)
{

	//printf(1,"Yash");
	k_cond_init(p);
	//printf(1,"1");

	return;

}
void cond_wait(cond_t *p, lock_t *g)
{
	//printf(1,"Shah");

   k_cond_wait(p, g);
	//printf(1,"2");

	return;
}
void cond_signal(cond_t *p)
{
	//printf(1,"CS");

	k_cond_signal(p);
	//printf(1,"3");
	return;
}


